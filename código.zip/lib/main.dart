import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';

const request = "https://api.hgbrasil.com/finance?format=json&key=eb0e4fcd";
void main() async {



  runApp(MaterialApp(
    home: Home(),
    theme: ThemeData(
      hintColor: Colors.amber,
      primaryColor: Colors.white,
      inputDecorationTheme: InputDecorationTheme(
        enabledBorder:
            OutlineInputBorder(borderSide: BorderSide(color: Colors.white)),
        focusedBorder:
            OutlineInputBorder(borderSide: BorderSide(color: Colors.amber)),
        hintStyle: TextStyle(color: Colors.amber),
      )),
  ));

}

Map dados;

Future <Map> getdata() async{
  if (dados==null){
    http.Response resposta = await http.get(Uri.parse(request));
    print(resposta.statusCode);
    if(resposta.statusCode==403){
      print ("limite estourado");
    }
    dados = (json.decode(resposta.body));
  }
  return dados;
}

class Home extends StatefulWidget {
  const Home({ Key? key }) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  
    void _clearAll(){
    controladorreal.text = "";
    controladordolar.text = "";
    controladoreuro.text = "";
    }
    
    
    
    
    final controladorreal = TextEditingController();
    final controladordolar = TextEditingController();
    final controladoreuro = TextEditingController();

    double dolar=0;
    double euro=0;


    void _mudareal(String text){
    if(text.isEmpty) {
      _clearAll();
      return;
    }
    double real = double.parse(text);
    controladordolar.text = (real/dolar).toStringAsFixed(2);
    controladoreuro.text = (real/euro).toStringAsFixed(2);
  }
 
  void _mudadolar(String text){
    if(text.isEmpty) {
      _clearAll();
      return;
    }
    double dolar = double.parse(text);
    controladorreal.text = (dolar * this.dolar).toStringAsFixed(2);
    controladoreuro.text = (dolar * this.dolar / euro).toStringAsFixed(2);
  }
 
  void _mudaeuro(String text){
    if(text.isEmpty) {
      _clearAll();
      return;
    }
    double euro = double.parse(text);
    controladorreal.text = (euro * this.euro).toStringAsFixed(2);
    controladordolar.text = (euro * this.euro / dolar).toStringAsFixed(2);
  }
  
  @override
  Widget build(BuildContext context) {    
    return Scaffold(

      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text("\$ Conversor \$"),
        backgroundColor: Colors.amber,
        centerTitle: true,
      ),
      body: FutureBuilder<Map>(
        future: getdata(),
        builder: (context,snapshot){
          switch(snapshot.connectionState){
            case ConnectionState.none:
            case ConnectionState.waiting:
              return Center(
                child: Text("Carregando dados...",
                  style: TextStyle(color: Colors.amber,
                  fontSize: 25.0,),
                  textAlign: TextAlign.center,                
                ));
            default:
            if (snapshot.hasError){
              return Center(
                child: Text("Erro ao carregar os dados!",
                  style: TextStyle(color: Colors.amber,
                  fontSize: 25.0,),
                  textAlign: TextAlign.center,                
                ));
            } else {
              dolar = snapshot.data! ["results"]["currencies"]["USD"]["buy"];
              euro = snapshot.data! ["results"]["currencies"]["EUR"]["buy"];
              return SingleChildScrollView(
                padding: EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Icon(Icons.monetization_on, size: 150.0, color: Colors.amber,),

                    buildTextField("Reais", "R\$", controladorreal, _mudareal),
                    Divider(),
                    buildTextField("Dólares", "US\$", controladordolar, _mudadolar),
                    Divider(),
                    buildTextField("Euros", "€", controladoreuro, _mudaeuro),
                  ],
                ),
              );
            }
          }
        },),
    );
  }
}

Widget buildTextField(String label, String prefix, TextEditingController c, Function f){
  return TextField(
    controller: c,
    decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: Colors.amber),
          border: OutlineInputBorder(),
          prefixText: prefix,
       ),
          style: TextStyle(color: Colors.amber, fontSize: 25.0),
          onChanged: (String value) {
              f(value);
            },
          keyboardType: TextInputType.number,
          );
}